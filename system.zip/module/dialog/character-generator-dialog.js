import { isCharacterGeneratorClassAllowed, setLastCharacterGeneratorSelection, getLastCharacterGeneratorSelection, getCharacterGeneratorGroupStates, setCharacterGeneratorGroupStates } from "../system/settings.js";
import { createCharacter, regenerateActor } from "../api/generator/character-generator.js";
import { classItemFromPack, findClassPacks, findCompendiumItem } from "../api/compendium.js";
import { executeCharacterCreationMacro } from "../api/macros.js";

class CharacterGeneratorDialog extends Application {
  constructor(actor = null, options = {}) {
    super(options);
    this.actor = actor;
    this.classPacks = findClassPacks();
    this.lastCharacterGeneratorSelection = getLastCharacterGeneratorSelection();
  }

  /** @override */
  static get defaultOptions() {
    const options = super.defaultOptions;
    options.id = "character-generator-dialog";
    options.classes = ["pirateborg"];
    options.title = game.i18n.localize("PB.CharacterGenerator");
    options.template = "systems/pirateborg/templates/dialog/character-generator-dialog.html";
    options.width = 420;
    options.height = "auto";
    return options;
  }

  /** @override */
  async getData(options = {}) {
    return foundry.utils.mergeObject(super.getData(options), {
      classGroups: await this.getClassDataGrouped(),
      forActor: this.actor !== undefined && this.actor !== null,
    });
  }

  async getClassDataGrouped() {
    const classes = await this.getClassData();
    const groups = {};
    const savedStates = getCharacterGeneratorGroupStates();

    for (const cls of classes) {
      // Extract module name from pack name (e.g., "pirateborg.class-buccaneer" -> "pirateborg")
      const moduleName = cls.pack.split(".")[0];
      const displayName = moduleName === "pirateborg" ? "Core" : game.modules.get(moduleName)?.title || moduleName;

      if (!groups[displayName]) {
        groups[displayName] = {
          name: displayName,
          moduleId: moduleName,
          classes: [],
        };
      }

      groups[displayName].classes.push(cls);
    }

    // Convert and sort: Core first, then alphabetically
    const sortedGroups = Object.values(groups).sort((a, b) => {
      if (a.name === "Core") return -1;
      if (b.name === "Core") return 1;
      return a.name.localeCompare(b.name);
    });

    for (const group of sortedGroups) {
      const hasCheckedClass = group.classes.some(cls => cls.checked);
      
      if (savedStates[group.name] !== undefined) {
        group.isOpen = savedStates[group.name];
      } else {
        if (group.name === "Core") {
          group.isOpen = true; // Core always starts open
        } else if (hasCheckedClass) {
          group.isOpen = true; // Groups with checked classes start open
        } else {
          group.isOpen = false; // Other groups start closed
        }
      }
    }

    return sortedGroups;
  }

  async getClassData() {
    return (await this.getClasses(this.classPacks))
      .map((cls) => ({
        name: cls.name,
        pack: cls.pack,
        requireBaseClass: cls.requireBaseClass,
        checked: this.lastCharacterGeneratorSelection.length > 0 ? this.lastCharacterGeneratorSelection.includes(cls.pack) : true,
      }))
      .filter((cls) => isCharacterGeneratorClassAllowed(cls.pack))
      .sort((a, b) => (a.name > b.name ? 1 : -1));
  }

  async getClasses(classPacks) {
    const classes = [];
    for (const classPack of classPacks) {
      const cls = await classItemFromPack(classPack);
      if (cls) {
        classes.push(cls);
      }
    }
    return classes;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".toggle-all").on("click", this._onToggleAll.bind(this));
    html.find(".toggle-none").on("click", this._onToggleNone.bind(this));
    html.find(".cancel-button").on("click", this._onCancel.bind(this));
    html.find(".character-generator-button").on("click", this._onCharacterGenerator.bind(this));
    html.find(".module-header").on("click", this._onToggleModule.bind(this));
  }

  _onToggleAll(event) {
    event.preventDefault();
    const form = $(event.currentTarget).parents(".character-generator-dialog")[0];
    $(form).find(".class-checkbox").prop("checked", true);
  }

  _onToggleNone(event) {
    event.preventDefault();
    const form = $(event.currentTarget).parents(".character-generator-dialog")[0];
    $(form).find(".class-checkbox").prop("checked", false);
  }

  async _onCancel(event) {
    event.preventDefault();
    await this.close();
  }

  async _onCharacterGenerator(event) {
    event.preventDefault();
    const form = $(event.currentTarget).parents(".character-generator-dialog")[0];
    const selection = [];

    $(form)
      .find("input:checked")
      .each(function () {
        selection.push($(this).attr("name"));
      });

    if (selection.length === 0) {
      // nothing selected, so bail
      return;
    }

    const selectedClasses = await this.getClasses(selection);
    const isValid = selectedClasses.some((selectedClass) => !selectedClass.requireBaseClass);
    if (!isValid) {
      // require at least one normal class
      return;
    }

    await setLastCharacterGeneratorSelection(selection);
    const randomClass = selectedClasses[Math.floor(Math.random() * selectedClasses.length)];

    await this.close();
    ui.notifications.info(`${game.users.current.name} is creating ${randomClass.name}.`);

    if (randomClass.characterGeneratorMacro) {
      const [compendium, macroName] = randomClass.characterGeneratorMacro.split(";");
      if (compendium) {
        const macro = await findCompendiumItem(compendium, macroName);
        await executeCharacterCreationMacro(macro, {
          selectedClass: randomClass,
          selectedClasses,
          actor: this.actor,
        });
        if (this.actor) {
          this.actor.sheet.render(true);
        }
      }
      return;
    }

    try {
      if (this.actor) {
        await regenerateActor(this.actor, randomClass);
      } else {
        const actor = await createCharacter(randomClass);
        actor.sheet.render(true);
      }
    } catch (err) {
      console.error(err);
      ui.notifications.error(`Error creating ${randomClass.name}. Check console for error log.`);
    }
  }

  async _onToggleModule(event) {
    event.preventDefault();
    const header = $(event.currentTarget);
    const moduleGroup = header.closest(".module-group");
    const classesDiv = moduleGroup.find(".module-classes");
    const icon = header.find("i");
    const groupName = header.find("span").text();

    classesDiv.slideToggle(200);
    icon.toggleClass("fa-chevron-down fa-chevron-right");

    const isOpen = icon.hasClass("fa-chevron-down");
    const savedStates = getCharacterGeneratorGroupStates();
    savedStates[groupName] = isOpen;
    await setCharacterGeneratorGroupStates(savedStates);
  }
}

/**
 * @param {PBActor} [actor]
 */
export const showCharacterGeneratorDialog = (actor) => {
  const characterGeneratorDialog = new CharacterGeneratorDialog(actor);
  characterGeneratorDialog.render(true);
};
